# Changelog

## V1.9 - 2026-11-09

- Added the "Honey, I blew up the images" Upscale direction for exactly 1920x1080 JPGs to 3840x2160.
- Bundled pica 10.0.3 and its MIT license for explicit, offline Lanczos3 resampling without cropping, browser-native resize fallback or added sharpening.
- Preserved default Shrink behavior, existing output choices, skipped-file view, filenames and JPEG metadata handling.
- Locked direction while a queue exists and restored it on Clear; opposite-size sources explain the required direction.
- Added full-size independent Lanczos reference checks, raw EXIF/XMP checks and 100-image upscale checks for native packages.
- Updated all four packages and versioned web assets; patched the existing Electron runtime within its current major version.

## V1.8 - 2026-10-14

- Added a launchable, offline Windows 10/11 (x64) desktop app and per-user installer.
- Added a Linux amd64 desktop app and DEB installer targeting Linux Mint 21.x and 22.x.
- Bundled the same versioned image workspace, icon, metadata handling, output choices and skipped-file view on every platform.
- Hidden app-download controls in every desktop edition; added separate platform downloads to the hosted page.
- Added native-platform installer, 100-image, output-download and shared-source checks in GitHub Actions.

## V1.7 - 2026-10-06

- Hidden the app-download button inside the native Mac app while retaining it on the website.
- Packaged the native application as `HISTI v1.7.app` with matching bundle version metadata.
- Made the Skipped counter open a skipped-only results view with filenames and reasons, plus Show All to return to the full queue.
- Kept filtering separate from processing and downloads, and packaged both editions from the same versioned web source.

## V1.6 - 2026-10-06

- Added independent 1920x1080 (16x9) and 3000x3000 (1x1) output checkboxes, both enabled by default.
- Applied output choices to the existing queue, processing, ready counts, previews and downloads.
- Reused completed outputs when re-enabled, and disabled processing/downloads when neither output is selected.
- Locked output choices during processing and ZIP creation.
- Updated the launchable Mac app and offline web package from the same versioned source.

## V1.5 - 2026-10-05

- Replaced the main download with a launchable `HISTI.app` for Apple Silicon and Intel Macs (macOS 12+), using the supplied app icon.
- Added native file selection and save dialogs for individual JPG and ZIP downloads.
- Processed sources sequentially, decoding each image once for both outputs and releasing output canvases immediately.
- Added image and ZIP progress, accurate source-image counts, and incremental result-row updates for large batches.
- Reduced ZIP memory use by retaining Blob payloads and calculating checksums in small chunks.
- Added output suffixes for filenames without a source-size token, including `ActionBible_86.jpg`.
- Kept a separately labeled offline web package; both packages embed the hosted page's versioned source.

## V1.4 - 2026-08-20

- Added default dual-output generation for each valid JPG: `16x9_1920x1080` and `1x1_3000x3000`.
- Added square output naming that changes `16x9_3840x2160` to `1x1_3000x3000`.
- Added 3000x3000 square rendering by scaling the source to 3000px high and center-cropping the width.
- Updated metadata dimension patching to use each output target's actual dimensions.

## V1.3 - 2026-08-17

- Added explicit Add to Queue / Replace Queue choice when selecting files after a queue already exists.
- Added immediate skipped rows for non-JPG selections.
- Preserved source JPEG metadata segments in resized outputs while updating common EXIF/XMP dimension fields to 1920x1080.
- Added `release_source.json` so the hosted page and downloadable ZIP can be confirmed against the same versioned source marker.

## V1.2 - 2026-08-14

- Updated the display name to `Honey, I Shrunk the Images`.
- Added the supplied HISTI icon as the app icon, web page icon, and visible page branding.
- Clarified app package download versus batch output download actions.
- Moved individual JPG download buttons to the far-left results column and simplified the results table.

## V1.1 - 2026-08-14

- Added the first public HISTI browser app.
- Added bulk JPG upload and local browser-side resizing from 3840x2160 to 1920x1080.
- Added filename conversion from `3840x2160` to `1920x1080` with all other filename text preserved.
- Added versioned offline ZIP packaging and GitHub Pages documentation.
